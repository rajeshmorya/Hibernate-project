package Com.PrimeVideo;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.Table;

@Entity
@Table(name = "Movies")
public class Movies
{
  @Id	
  @Column(name = "Movies_Id")	
  private Integer Movies_Id;
  
  @OneToOne(targetEntity = User_Account.class, cascade = CascadeType.ALL)
  @JoinColumn(name = "User_AccountId", referencedColumnName = "Login_Id")
  private User_Account User_AccountId;

public Integer getMovies_Id() {
	return Movies_Id;
}

public void setMovies_Id(Integer movies_Id) {
	Movies_Id = movies_Id;
}

public User_Account getUser_AccountId() {
	return User_AccountId;
}

public void setUser_AccountId(User_Account user_AccountId) {
	User_AccountId = user_AccountId;
}
}
