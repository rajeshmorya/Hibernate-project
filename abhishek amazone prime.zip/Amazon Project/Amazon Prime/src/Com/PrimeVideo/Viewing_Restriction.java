package Com.PrimeVideo;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.Table;

@Entity
@Table(name = "Viewing_Restriction")
public class Viewing_Restriction 
{  
	@Id
	@Column(name = "Restrict_Pin")
    private Integer Restrict_Pin; 
	
	@OneToOne(targetEntity = Parental_Control.class, cascade = CascadeType.ALL)
	@JoinColumn(name = "Control_Id", referencedColumnName = "Parental_Id")
	private Parental_Control Control_Id;

	public Integer getRestrict_Pin() {
		return Restrict_Pin;
	}

	public void setRestrict_Pin(Integer restrict_Pin) {
		Restrict_Pin = restrict_Pin;
	}

	public Parental_Control getControl_Id() {
		return Control_Id;
	}

	public void setControl_Id(Parental_Control control_Id) {
		Control_Id = control_Id;
	}
  
}
