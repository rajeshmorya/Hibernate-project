package Com.PrimeVideo;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.AnnotationConfiguration;

public class LogicFile {
	void User_UserAccount() {
		AnnotationConfiguration cfg = new AnnotationConfiguration();

		cfg.configure("hibernate.cfg.xml");

		SessionFactory factory = cfg.buildSessionFactory();

		Session session = factory.openSession();

		User user = new User();

		user.setUser_Name("Deepak");

		user.setMobile_No(9415);

		User_Account account = new User_Account();

		account.setLogin_Id(8415);

		account.setLogin_Password("sonu@123");

		account.setUser_Id(user);

		Transaction tx = session.beginTransaction();

		session.save(account);

		tx.commit();

		session.close();

		System.out.println("Object Saved Successfully!");

		factory.close();

	}

	void UserAccount_UsrProfile() {
		AnnotationConfiguration cfg = new AnnotationConfiguration();

		cfg.configure("hibernate.cfg.xml");

		SessionFactory factory = cfg.buildSessionFactory();

		Session session = factory.openSession();

		User_Account account = (User_Account) session.get(User_Account.class, 8415);

		User_Profile p = new User_Profile();

		p.setProfile_Id(1293);

		p.setProfile_Name("Deepak");

		p.setAccount(account);

		Transaction tx = session.beginTransaction();

		session.save(p);

		session.save(account);

		tx.commit();

		session.close();

		System.out.println("Object Updated Successfully!");

		factory.close();

	}

	void UsrProfile_WathList() {
		AnnotationConfiguration cfg = new AnnotationConfiguration();

		cfg.configure("hibernate.cfg.xml");

		SessionFactory factory = cfg.buildSessionFactory();

		Session session = factory.openSession();

		User_Profile p = (User_Profile) session.get(User_Profile.class, 1293);

		Watch_List w = new Watch_List();

		w.setList_Id(101);

		w.setList_Name("My Watchlist");

		w.setProfile_Id(p);

		Transaction tx = session.beginTransaction();

		session.save(p);

		session.save(w);

		tx.commit();

		session.close();

		System.out.println("Object Updated Successfully!");

		factory.close();

	}

	void UsrProfile_AccountSetting() {
		AnnotationConfiguration cfg = new AnnotationConfiguration();

		cfg.configure("hibernate.cfg.xml");

		SessionFactory factory = cfg.buildSessionFactory();

		Session session = factory.openSession();

		User_Profile u = (User_Profile) session.get(User_Profile.class, 1293);

		Acccount_Settting s = new Acccount_Settting();

		s.setAccount_SettingId(201);

		s.setProfile_Id(u);

		Transaction tx = session.beginTransaction();

		session.save(u);

		session.save(s);

		tx.commit();

		session.close();

		System.out.println("Object Updated Successfully!");

		factory.close();

	}

	void UsrProfile_WatchAnywhere() {
		AnnotationConfiguration cfg = new AnnotationConfiguration();

		cfg.configure("hibernate.cfg.xml");

		SessionFactory factory = cfg.buildSessionFactory();

		Session session = factory.openSession();

		User_Profile u = (User_Profile) session.get(User_Profile.class, 1293);

		Watch_Anywhere a = new Watch_Anywhere();

		a.setId(301);

		a.setProfile_Id(u);

		Transaction tx = session.beginTransaction();

		session.save(u);

		session.save(a);

		tx.commit();

		session.close();

		System.out.println("Object Updated Successfully!");

		factory.close();

	}

	void UsrProfile_HelpMenu() {
		AnnotationConfiguration cfg = new AnnotationConfiguration();

		cfg.configure("hibernate.cfg.xml");

		SessionFactory factory = cfg.buildSessionFactory();

		Session session = factory.openSession();

		User_Profile u = (User_Profile) session.get(User_Profile.class, 1293);

		Help_Menu h = new Help_Menu();

		h.setHelp_Id(401);

		h.setProfil_Id(u);

		Transaction tx = session.beginTransaction();

		session.save(u);

		session.save(h);

		tx.commit();

		session.close();

		System.out.println("Object Updated Successfully!");

		factory.close();

	}

	void AccountSetting_YourAccount() {
		AnnotationConfiguration cfg = new AnnotationConfiguration();

		cfg.configure("hibernate.cfg.xml");

		SessionFactory factory = cfg.buildSessionFactory();

		Session session = factory.openSession();

		Acccount_Settting s = (Acccount_Settting) session.get(Acccount_Settting.class, 201);

		Your_Account y = new Your_Account();

		y.setYour_AccountId(501);

		y.setAcc_Id(s);

		Transaction tx = session.beginTransaction();

		session.save(s);

		session.save(y);

		tx.commit();

		session.close();

		System.out.println("Object Updated Successfully!");

		factory.close();

	}

	void YourAccount_YourDetails() {
		AnnotationConfiguration cfg = new AnnotationConfiguration();

		cfg.configure("hibernate.cfg.xml");

		SessionFactory factory = cfg.buildSessionFactory();

		Session session = factory.openSession();

		Your_Account y = (Your_Account) session.get(Your_Account.class, 501);

		Your_Details d = new Your_Details();

		d.setDetails_Id(601);

		d.setEmail("katariyadeepak123@gmail.com");

		d.setAccount_Id(y);

		Transaction tx = session.beginTransaction();

		session.save(y);

		session.save(d);

		tx.commit();

		session.close();

		System.out.println("Object Updated Successfully!");

		factory.close();

	}

	void YourAccount_Prime() {
		AnnotationConfiguration cfg = new AnnotationConfiguration();

		cfg.configure("hibernate.cfg.xml");

		SessionFactory factory = cfg.buildSessionFactory();

		Session session = factory.openSession();

		Your_Account y = (Your_Account) session.get(Your_Account.class, 501);

		Prime p = new Prime();

		p.setPrime_Id(701);

		p.setPrime_Plan("Basic_Plan");

		p.setAccount_Id(y);

		Transaction tx = session.beginTransaction();

		session.save(y);

		session.save(p);

		tx.commit();

		session.close();

		System.out.println("Object Updated Successfully!");

		factory.close();

	}

	void YourAccount_PaymentHistory() {
		AnnotationConfiguration cfg = new AnnotationConfiguration();

		cfg.configure("hibernate.cfg.xml");

		SessionFactory factory = cfg.buildSessionFactory();

		Session session = factory.openSession();

		Your_Account y = (Your_Account) session.get(Your_Account.class, 501);

		Payment_History h = new Payment_History();

		h.setPayment_Id(701);

		h.setPayment_Mode("Debit_Card");

		h.setAccount_Id(y);

		Payment_History h1 = new Payment_History();

		h1.setPayment_Id(702);

		h1.setPayment_Mode("Credit_Card");

		h1.setAccount_Id(y);

		Payment_History h2 = new Payment_History();

		h2.setPayment_Id(703);

		h2.setPayment_Mode("Net_Banking");

		h2.setAccount_Id(y);

		Transaction tx = session.beginTransaction();

		session.save(y);

		session.save(h);

		session.save(h1);

		session.save(h2);

		tx.commit();

		session.close();

		System.out.println("Object Updated Successfully!");

		factory.close();

	}

	void AccountSetting_Palyback() {
		AnnotationConfiguration cfg = new AnnotationConfiguration();

		cfg.configure("hibernate.cfg.xml");

		SessionFactory factory = cfg.buildSessionFactory();

		Session session = factory.openSession();

		Acccount_Settting s = (Acccount_Settting) session.get(Acccount_Settting.class, 201);

		Playback p = new Playback();

		p.setPlayback_Id(801);

		p.setAccount_Id(s);

		Transaction tx = session.beginTransaction();

		session.save(s);

		session.save(p);

		tx.commit();

		session.close();

		System.out.println("Object Updated Successfully!");

		factory.close();

	}

	void Palyback_Autoplay() {
		AnnotationConfiguration cfg = new AnnotationConfiguration();

		cfg.configure("hibernate.cfg.xml");

		SessionFactory factory = cfg.buildSessionFactory();

		Session session = factory.openSession();

		Playback p = (Playback) session.get(Playback.class, 801);

		Auto_Play a = new Auto_Play();

		a.setPlay_Id(901);

		a.setSet_Mode("On or Off");

		a.setPlayback_Id(p);

		Transaction tx = session.beginTransaction();

		session.save(a);

		session.save(p);

		tx.commit();

		session.close();

		System.out.println("Object Updated Successfully!");

		factory.close();

	}

	void AccountSetting_ParentalControl() {
		AnnotationConfiguration cfg = new AnnotationConfiguration();

		cfg.configure("hibernate.cfg.xml");

		SessionFactory factory = cfg.buildSessionFactory();

		Session session = factory.openSession();

		Acccount_Settting s = (Acccount_Settting) session.get(Acccount_Settting.class, 201);

		Parental_Control c = new Parental_Control();

		c.setParental_Id(901);

		c.setAccount_Id(s);

		Transaction tx = session.beginTransaction();

		session.save(s);

		session.save(c);

		tx.commit();

		session.close();

		System.out.println("Object Updated Successfully!");

		factory.close();

	}

	void ParentalControl_Prime_VideoPin() {
		AnnotationConfiguration cfg = new AnnotationConfiguration();

		cfg.configure("hibernate.cfg.xml");

		SessionFactory factory = cfg.buildSessionFactory();

		Session session = factory.openSession();

		Parental_Control s = (Parental_Control) session.get(Parental_Control.class, 901);

		Prime_VideoPin c = new Prime_VideoPin();

		c.setVideo_Pin(3429);

		c.setControl_Id(s);

		Transaction tx = session.beginTransaction();

		session.save(s);

		session.save(c);

		tx.commit();

		session.close();

		System.out.println("Object Updated Successfully!");

		factory.close();

	}

	void ParentalControl_Restriction() {
		AnnotationConfiguration cfg = new AnnotationConfiguration();

		cfg.configure("hibernate.cfg.xml");

		SessionFactory factory = cfg.buildSessionFactory();

		Session session = factory.openSession();

		Parental_Control s = (Parental_Control) session.get(Parental_Control.class, 901);

		Viewing_Restriction c = new Viewing_Restriction();

		c.setRestrict_Pin(3428);

		c.setControl_Id(s);
		Transaction tx = session.beginTransaction();

		session.save(s);

		session.save(c);

		tx.commit();

		session.close();

		System.out.println("Object Updated Successfully!");

		factory.close();

	}

	void AccountSetting_Subtitles() {
		AnnotationConfiguration cfg = new AnnotationConfiguration();

		cfg.configure("hibernate.cfg.xml");

		SessionFactory factory = cfg.buildSessionFactory();

		Session session = factory.openSession();

		Acccount_Settting s = (Acccount_Settting) session.get(Acccount_Settting.class, 201);

		Subtitles c = new Subtitles();

		c.setSubtitles_Id(1001);

		c.setAccount_Id(s);

		Transaction tx = session.beginTransaction();

		session.save(s);

		session.save(c);

		tx.commit();

		session.close();

		System.out.println("Object Updated Successfully!");

		factory.close();

	}

	void Subtitle_SubtiltePresets() {
		AnnotationConfiguration cfg = new AnnotationConfiguration();

		cfg.configure("hibernate.cfg.xml");

		SessionFactory factory = cfg.buildSessionFactory();

		Session session = factory.openSession();

		Subtitles s = (Subtitles) session.get(Subtitles.class, 1001);

		Subtitle_Presets c = new Subtitle_Presets();

		c.setPresets_Id(2001);

		c.setSubtilte_Id(s);

		Transaction tx = session.beginTransaction();

		session.save(s);

		session.save(c);

		tx.commit();

		session.close();

		System.out.println("Object Updated Successfully!");

		factory.close();

	}

	void Subtilte_DefaultPreset() {
		AnnotationConfiguration cfg = new AnnotationConfiguration();

		cfg.configure("hibernate.cfg.xml");

		SessionFactory factory = cfg.buildSessionFactory();

		Session session = factory.openSession();

		Subtitles s = (Subtitles) session.get(Subtitles.class, 1001);

		Default_Preset c = new Default_Preset();

		c.setDefault_Id(3001);

		c.setSub_Id(s);

		Transaction tx = session.beginTransaction();

		session.save(s);

		session.save(c);

		tx.commit();

		session.close();

		System.out.println("Object Updated Successfully!");

		factory.close();

	}

	void Subtilte_YourPreset() {
		AnnotationConfiguration cfg = new AnnotationConfiguration();

		cfg.configure("hibernate.cfg.xml");

		SessionFactory factory = cfg.buildSessionFactory();

		Session session = factory.openSession();

		Subtitles s = (Subtitles) session.get(Subtitles.class, 1001);

		Your_Presets c = new Your_Presets();

		c.setYour_PresetId(4001);

		c.setPreset_name("Subtitle Preset 1");

		c.setSub_Id(s);

		Your_Presets c2 = new Your_Presets();

		c2.setYour_PresetId(4002);

		c2.setPreset_name("Subtitle Preset 2");

		c2.setSub_Id(s);

		Transaction tx = session.beginTransaction();

		session.save(s);

		session.save(c);

		session.save(c2);

		tx.commit();

		session.close();

		System.out.println("Object Updated Successfully!");

		factory.close();

	}

	void AccountSetting_YourDevice() {
		AnnotationConfiguration cfg = new AnnotationConfiguration();

		cfg.configure("hibernate.cfg.xml");

		SessionFactory factory = cfg.buildSessionFactory();

		Session session = factory.openSession();

		Acccount_Settting s = (Acccount_Settting) session.get(Acccount_Settting.class, 201);

		Your_Devices c = new Your_Devices();

		c.setDevice_Id(5001);

		c.setAccount_Id(s);

		Transaction tx = session.beginTransaction();

		session.save(s);

		session.save(c);

		tx.commit();

		session.close();

		System.out.println("Object Updated Successfully!");

		factory.close();

	}

	void YourDevice_RegisterDevice() {
		AnnotationConfiguration cfg = new AnnotationConfiguration();

		cfg.configure("hibernate.cfg.xml");

		SessionFactory factory = cfg.buildSessionFactory();

		Session session = factory.openSession();

		Your_Devices c = (Your_Devices) session.get(Your_Devices.class, 5001);

		Register_Another_Device s = new Register_Another_Device();

		s.setAnother_DeviceId(6001);

		s.setDevice_Id(c);

		Transaction tx = session.beginTransaction();

		session.save(s);

		session.save(c);

		tx.commit();

		session.close();

		System.out.println("Object Updated Successfully!");

		factory.close();

	}

	void YourDevice_YourDevices() {
		AnnotationConfiguration cfg = new AnnotationConfiguration();

		cfg.configure("hibernate.cfg.xml");

		SessionFactory factory = cfg.buildSessionFactory();

		Session session = factory.openSession();

		Your_Devices c = (Your_Devices) session.get(Your_Devices.class, 5001);

		Your_Resistered_Devices s = new Your_Resistered_Devices();

		s.setDevice_Id(7001);

		s.setDevice_Name("Android1");

		s.setYour_Id(c);

		Your_Resistered_Devices s1 = new Your_Resistered_Devices();

		s1.setDevice_Id(7002);

		s1.setDevice_Name("Android2");

		s1.setYour_Id(c);

		Transaction tx = session.beginTransaction();

		session.save(s);

		session.save(s1);

		session.save(c);

		tx.commit();

		session.close();

		System.out.println("Object Updated Successfully!");

		factory.close();

	}

	void AccountSetting_Languages() {
		AnnotationConfiguration cfg = new AnnotationConfiguration();

		cfg.configure("hibernate.cfg.xml");

		SessionFactory factory = cfg.buildSessionFactory();

		Session session = factory.openSession();

		Acccount_Settting c = (Acccount_Settting) session.get(Acccount_Settting.class, 201);

		Language s = new Language();

		s.setLanguage_Code(8001);

		s.setAccount_Id(c);

		Transaction tx = session.beginTransaction();

		session.save(s);

		session.save(c);

		tx.commit();

		session.close();

		System.out.println("Object Updated Successfully!");

		factory.close();

	}

	void Languages_WebsiteLanguages() {
		AnnotationConfiguration cfg = new AnnotationConfiguration();

		cfg.configure("hibernate.cfg.xml");

		SessionFactory factory = cfg.buildSessionFactory();

		Session session = factory.openSession();

		Language c = (Language) session.get(Language.class, 8001);

		Website_Languages s = new Website_Languages();

		s.setWebsiteId(1101);

		s.setLanguage_name("English");

		s.setLang_Id(c);

		Website_Languages s1 = new Website_Languages();

		s1.setWebsiteId(1102);

		s1.setLanguage_name("Hindi");

		s1.setLang_Id(c);

		Website_Languages s2 = new Website_Languages();

		s2.setWebsiteId(1103);

		s2.setLanguage_name("French");

		s2.setLang_Id(c);

		Transaction tx = session.beginTransaction();

		session.save(s);

		session.save(s1);

		session.save(s2);

		session.save(c);

		tx.commit();

		session.close();

		System.out.println("Object Updated Successfully!");

		factory.close();

	}

	void AccountSetting_WatchHistory() {
		AnnotationConfiguration cfg = new AnnotationConfiguration();

		cfg.configure("hibernate.cfg.xml");

		SessionFactory factory = cfg.buildSessionFactory();

		Session session = factory.openSession();

		Acccount_Settting c = (Acccount_Settting) session.get(Acccount_Settting.class, 201);

		Watch_History s = new Watch_History();

		s.setHistory_ID(1201);

		s.setAccount_Id(c);

		Transaction tx = session.beginTransaction();

		session.save(s);

		session.save(c);

		tx.commit();

		session.close();

		System.out.println("Object Updated Successfully!");

		factory.close();

	}

	void UserAccount_Home() {
		AnnotationConfiguration cfg = new AnnotationConfiguration();

		cfg.configure("hibernate.cfg.xml");

		SessionFactory factory = cfg.buildSessionFactory();

		Session session = factory.openSession();

		User_Account c = (User_Account) session.get(User_Account.class, 8415);

		Home s = new Home();

		s.setHome_Id(1401);

		s.setUser_AccountId(c);

		Transaction tx = session.beginTransaction();

		session.save(s);

		session.save(c);

		tx.commit();

		session.close();

		System.out.println("Object Updated Successfully!");

		factory.close();

	}

	void WatchHistory_YourHistory() {
		AnnotationConfiguration cfg = new AnnotationConfiguration();

		cfg.configure("hibernate.cfg.xml");

		SessionFactory factory = cfg.buildSessionFactory();

		Session session = factory.openSession();

		Watch_History c = (Watch_History) session.get(Watch_History.class, 1201);

		Your_WatchHistory s = new Your_WatchHistory();

		s.setYour_HistoryId(1301);

		s.setWatch_HistoryId(c);

		Transaction tx = session.beginTransaction();

		session.save(s);

		session.save(c);

		tx.commit();

		session.close();

		System.out.println("Object Updated Successfully!");

		factory.close();

	}

	void UserAccount_TvShows() {
		AnnotationConfiguration cfg = new AnnotationConfiguration();

		cfg.configure("hibernate.cfg.xml");

		SessionFactory factory = cfg.buildSessionFactory();

		Session session = factory.openSession();

		User_Account c = (User_Account) session.get(User_Account.class, 8415);

		TV_Shows s = new TV_Shows();

		s.setTv_ID(1501);

		s.setUser_Id(c);

		Transaction tx = session.beginTransaction();

		session.save(s);

		session.save(c);

		tx.commit();

		session.close();

		System.out.println("Object Updated Successfully!");

		factory.close();

	}

	void UserAccount_Movies() {
		AnnotationConfiguration cfg = new AnnotationConfiguration();

		cfg.configure("hibernate.cfg.xml");

		SessionFactory factory = cfg.buildSessionFactory();

		Session session = factory.openSession();

		User_Account c = (User_Account) session.get(User_Account.class, 8415);

		Movies s = new Movies();

		s.setMovies_Id(1601);

		s.setUser_AccountId(c);

		Transaction tx = session.beginTransaction();

		session.save(s);

		session.save(c);

		tx.commit();

		session.close();

		System.out.println("Object Updated Successfully!");

		factory.close();

	}

	void UserAccount_Kids() {
		AnnotationConfiguration cfg = new AnnotationConfiguration();

		cfg.configure("hibernate.cfg.xml");

		SessionFactory factory = cfg.buildSessionFactory();

		Session session = factory.openSession();

		User_Account c = (User_Account) session.get(User_Account.class, 8415);

		Kids s = new Kids();

		s.setKids_Id(1701);

		s.setUser_Id(c);

		Transaction tx = session.beginTransaction();

		session.save(s);

		session.save(c);

		tx.commit();

		session.close();

		System.out.println("Object Updated Successfully!");

		factory.close();

	}

	void Home_HindiMovies() {
		AnnotationConfiguration cfg = new AnnotationConfiguration();

		cfg.configure("hibernate.cfg.xml");

		SessionFactory factory = cfg.buildSessionFactory();

		Session session = factory.openSession();

		Home c = (Home) session.get(Home.class, 1401);

		Movies_IN_Hindi s = new Movies_IN_Hindi();

		s.setHindi_Id(1801);

		s.setMoive_name("Batla House");

		s.setHome_Id(c);

		Movies_IN_Hindi s1 = new Movies_IN_Hindi();

		s1.setHindi_Id(1802);

		s1.setMoive_name("Kabir Singh");

		s1.setHome_Id(c);

		Transaction tx = session.beginTransaction();

		session.save(s);

		session.save(s1);

		session.save(c);

		tx.commit();

		session.close();

		System.out.println("Object Updated Successfully!");

		factory.close();

	}

	void Home_AmazonWebSeries() {
		AnnotationConfiguration cfg = new AnnotationConfiguration();

		cfg.configure("hibernate.cfg.xml");

		SessionFactory factory = cfg.buildSessionFactory();

		Session session = factory.openSession();

		Home c = (Home) session.get(Home.class, 1401);

		Amazon_Web_Series s = new Amazon_Web_Series();

		s.setAmazonId(1901);

		s.setSeries_Name("Mirzapur");

		s.setHome_Id(c);

		Amazon_Web_Series s1 = new Amazon_Web_Series();

		s1.setAmazonId(1902);

		s1.setSeries_Name("The Family Man");

		s1.setHome_Id(c);

		Transaction tx = session.beginTransaction();

		session.save(s);

		session.save(s1);

		session.save(c);

		tx.commit();

		session.close();

		System.out.println("Object Updated Successfully!");

		factory.close();

	}

	void Home_MoviesinEnglish() {
		AnnotationConfiguration cfg = new AnnotationConfiguration();

		cfg.configure("hibernate.cfg.xml");

		SessionFactory factory = cfg.buildSessionFactory();

		Session session = factory.openSession();

		Home c = (Home) session.get(Home.class, 1401);

		Movies_InEnglish s = new Movies_InEnglish();

		s.setMovies_Id(2001);

		s.setMovies_name("The Nun");

		s.setHome_Id(c);

		Movies_InEnglish s1 = new Movies_InEnglish();

		s1.setMovies_Id(2002);

		s1.setMovies_name("Harry Potter");

		s1.setHome_Id(c);

		Transaction tx = session.beginTransaction();

		session.save(s);

		session.save(s1);

		session.save(c);

		tx.commit();

		session.close();

		System.out.println("Object Updated Successfully!");

		factory.close();
	}

	void Home_Genres() {
		AnnotationConfiguration cfg = new AnnotationConfiguration();

		cfg.configure("hibernate.cfg.xml");

		SessionFactory factory = cfg.buildSessionFactory();

		Session session = factory.openSession();

		Home c = (Home) session.get(Home.class, 1401);

		Genres s = new Genres();

		s.setGenres_id(2101);

		s.setGenre_Type("Comedy");

		s.setHome_id(c);

		Genres s1 = new Genres();

		s1.setGenres_id(2102);

		s1.setGenre_Type("Action");

		s1.setHome_id(c);

		Genres s2 = new Genres();

		s2.setGenres_id(2103);

		s2.setGenre_Type("Advanture");

		s2.setHome_id(c);

		Transaction tx = session.beginTransaction();

		session.save(s);

		session.save(s1);

		session.save(s2);

		session.save(c);

		tx.commit();

		session.close();

		System.out.println("Object Updated Successfully!");

		factory.close();
	}

	void TVshow_Recommanded() {
		AnnotationConfiguration cfg = new AnnotationConfiguration();

		cfg.configure("hibernate.cfg.xml");

		SessionFactory factory = cfg.buildSessionFactory();

		Session session = factory.openSession();

		TV_Shows c = (TV_Shows) session.get(TV_Shows.class, 1501);

		Recommanded_shows s = new Recommanded_shows();

		s.setShows_Id(2201);

		s.setShow_Name("Jack and Ryan");

		s.setTv_Id(c);

		Recommanded_shows s2 = new Recommanded_shows();

		s2.setShows_Id(2202);

		s2.setShow_Name("Super Natural");

		s2.setTv_Id(c);

		Transaction tx = session.beginTransaction();

		session.save(s);

		session.save(s2);

		session.save(c);

		tx.commit();

		session.close();

		System.out.println("Object Updated Successfully!");

		factory.close();
	}

	void TVshow_Throwback() {
		AnnotationConfiguration cfg = new AnnotationConfiguration();

		cfg.configure("hibernate.cfg.xml");

		SessionFactory factory = cfg.buildSessionFactory();

		Session session = factory.openSession();

		TV_Shows c = (TV_Shows) session.get(TV_Shows.class, 1501);

		ThrowBack_Tv s = new ThrowBack_Tv();

		s.setTv_Id(2301);

		s.setShows_name("Shaktiman");

		s.setTV_Id(c);

		ThrowBack_Tv s1 = new ThrowBack_Tv();

		s1.setTv_Id(2302);

		s1.setShows_name("Malgudi Days");

		s1.setTV_Id(c);

		Transaction tx = session.beginTransaction();

		session.save(s);

		session.save(s1);

		session.save(c);

		tx.commit();

		session.close();

		System.out.println("Object Updated Successfully!");

		factory.close();
	}

	void TVshow_Thriller() {
		AnnotationConfiguration cfg = new AnnotationConfiguration();

		cfg.configure("hibernate.cfg.xml");

		SessionFactory factory = cfg.buildSessionFactory();

		Session session = factory.openSession();

		TV_Shows c = (TV_Shows) session.get(TV_Shows.class, 1501);

		Thriller_TV s = new Thriller_TV();

		s.setThriller_Id(2401);

		s.setShows_name("Scandal");

		s.setShows_Id(c);

		Thriller_TV s1 = new Thriller_TV();

		s1.setThriller_Id(2402);

		s1.setShows_name("The Robot");

		s1.setShows_Id(c);

		Transaction tx = session.beginTransaction();

		session.save(s);

		session.save(s1);

		session.save(c);

		tx.commit();

		session.close();

		System.out.println("Object Updated Successfully!");

		factory.close();
	}

	void TVshow_DramaTv() {
		AnnotationConfiguration cfg = new AnnotationConfiguration();

		cfg.configure("hibernate.cfg.xml");

		SessionFactory factory = cfg.buildSessionFactory();

		Session session = factory.openSession();

		TV_Shows c = (TV_Shows) session.get(TV_Shows.class, 1501);

		Drama_Tv s = new Drama_Tv();

		s.setDrama_Id(2501);

		s.setShow_name("Criminal Minds");

		s.setTv_Id(c);

		Drama_Tv s1 = new Drama_Tv();

		s1.setDrama_Id(2502);

		s1.setShow_name("Taken");

		s1.setTv_Id(c);

		Transaction tx = session.beginTransaction();

		session.save(s);

		session.save(s1);

		session.save(c);

		tx.commit();

		session.close();

		System.out.println("Object Updated Successfully!");

		factory.close();
	}

	void Movies_Hollywood() {
		AnnotationConfiguration cfg = new AnnotationConfiguration();

		cfg.configure("hibernate.cfg.xml");

		SessionFactory factory = cfg.buildSessionFactory();

		Session session = factory.openSession();

		Movies c = (Movies) session.get(Movies.class, 1601);

		Hollywood_Movies s = new Hollywood_Movies();

		s.setMovies_Id(2601);

		s.setMoive_name("MIB");

		s.setId(c);

		Hollywood_Movies s1 = new Hollywood_Movies();

		s1.setMovies_Id(2602);

		s1.setMoive_name("BumbLee");

		s1.setId(c);

		Transaction tx = session.beginTransaction();

		session.save(s);

		session.save(s1);

		session.save(c);

		tx.commit();

		session.close();

		System.out.println("Object Updated Successfully!");

		factory.close();
	}

	void Movies_Language() {
		AnnotationConfiguration cfg = new AnnotationConfiguration();

		cfg.configure("hibernate.cfg.xml");

		SessionFactory factory = cfg.buildSessionFactory();

		Session session = factory.openSession();

		Movies c = (Movies) session.get(Movies.class, 1601);

		Movies_ByLanguage s = new Movies_ByLanguage();

		s.setMovies_Id(2701);

		s.setLanguage_name("Hindi");

		s.setMovie_Id(c);

		Movies_ByLanguage s1 = new Movies_ByLanguage();

		s1.setMovies_Id(2702);

		s1.setLanguage_name("English");

		s1.setMovie_Id(c);

		Transaction tx = session.beginTransaction();

		session.save(s);

		session.save(s1);

		session.save(c);

		tx.commit();

		session.close();

		System.out.println("Object Updated Successfully!");

		factory.close();
	}

	void Movies_Bollywood() {
		AnnotationConfiguration cfg = new AnnotationConfiguration();

		cfg.configure("hibernate.cfg.xml");

		SessionFactory factory = cfg.buildSessionFactory();

		Session session = factory.openSession();

		Movies c = (Movies) session.get(Movies.class, 1601);

		Bollywood_Movies s = new Bollywood_Movies();

		s.setBollywood_Id(2801);

		s.setMovieName("Batla House");

		s.setMovies_Id(c);

		Bollywood_Movies s1 = new Bollywood_Movies();

		s1.setBollywood_Id(2802);

		s1.setMovieName("3 Idiots");

		s1.setMovies_Id(c);

		Transaction tx = session.beginTransaction();

		session.save(s);

		session.save(s1);

		session.save(c);

		tx.commit();

		session.close();

		System.out.println("Object Updated Successfully!");

		factory.close();
	}

	void Movies_Genres() {
		AnnotationConfiguration cfg = new AnnotationConfiguration();

		cfg.configure("hibernate.cfg.xml");

		SessionFactory factory = cfg.buildSessionFactory();

		Session session = factory.openSession();

		Movies c = (Movies) session.get(Movies.class, 1601);

		Movie_Genres s = new Movie_Genres();

		s.setMovie_GenresId(2901);

		s.setGenre_Type("Action");

		s.setMoive_Id(c);

		Movie_Genres s1 = new Movie_Genres();

		s1.setMovie_GenresId(2902);

		s1.setGenre_Type("Comedy");

		s1.setMoive_Id(c);

		Transaction tx = session.beginTransaction();

		session.save(s);

		session.save(s1);

		session.save(c);

		tx.commit();

		session.close();

		System.out.println("Object Updated Successfully!");

		factory.close();
	}

	void Kids_familyMovies() {
		AnnotationConfiguration cfg = new AnnotationConfiguration();

		cfg.configure("hibernate.cfg.xml");

		SessionFactory factory = cfg.buildSessionFactory();

		Session session = factory.openSession();

		Kids c = (Kids) session.get(Kids.class, 1701);

		Kids_and_family_Movies s = new Kids_and_family_Movies();

		s.setFamilyMovies_Id(3001);

		s.setMoive_Name("Classic Popaye");

		s.setKid_id(c);

		Kids_and_family_Movies s1 = new Kids_and_family_Movies();

		s1.setFamilyMovies_Id(3002);

		s1.setMoive_Name("Super Bheem");

		s1.setKid_id(c);

		Transaction tx = session.beginTransaction();

		session.save(s);

		session.save(s1);

		session.save(c);

		tx.commit();

		session.close();

		System.out.println("Object Updated Successfully!");

		factory.close();
	}

	void Kids_Fantasy() {
		AnnotationConfiguration cfg = new AnnotationConfiguration();

		cfg.configure("hibernate.cfg.xml");

		SessionFactory factory = cfg.buildSessionFactory();

		Session session = factory.openSession();

		Kids c = (Kids) session.get(Kids.class, 1701);

		Fantasy_Movies s = new Fantasy_Movies();

		s.setFantasy_Id(3101);

		s.setMoive_Name("The Snow Queen");

		s.setKid_Id(c);

		Fantasy_Movies s1 = new Fantasy_Movies();

		s1.setFantasy_Id(3102);

		s1.setMoive_Name("Legend of the Monkey King");

		s1.setKid_Id(c);

		Transaction tx = session.beginTransaction();

		session.save(s);

		session.save(s1);

		session.save(c);

		tx.commit();

		session.close();

		System.out.println("Object Updated Successfully!");

		factory.close();
	}

	void Kids_IndianToons() {
		AnnotationConfiguration cfg = new AnnotationConfiguration();

		cfg.configure("hibernate.cfg.xml");

		SessionFactory factory = cfg.buildSessionFactory();

		Session session = factory.openSession();

		Kids c = (Kids) session.get(Kids.class, 1701);

		Indian_Toons s = new Indian_Toons();

		s.setTonns_Id(3201);

		s.setName("Bajrang");

		s.setKid_Id(c);

		Indian_Toons s1 = new Indian_Toons();

		s1.setTonns_Id(3202);

		s1.setName("Raju RajKumar");

		s1.setKid_Id(c);

		Transaction tx = session.beginTransaction();

		session.save(s);

		session.save(s1);

		session.save(c);

		tx.commit();

		session.close();

		System.out.println("Object Updated Successfully!");

		factory.close();
	}

	public static void main(String args[])

	{

	}

}
