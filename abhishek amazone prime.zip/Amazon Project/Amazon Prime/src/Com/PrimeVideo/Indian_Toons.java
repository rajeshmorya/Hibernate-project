package Com.PrimeVideo;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

@Entity
@Table(name = "Indian_Toons")
public class Indian_Toons 
{
	@Id
	@Column(name = "Tonns_Id")
    private Integer Tonns_Id;
	
	@Column(name = "name")
	private String name;
	
	@ManyToOne(targetEntity = Kids.class, cascade =  CascadeType.ALL)
	@JoinColumn(name= "kid_Id", referencedColumnName =  "Kids_Id")
	private Kids kid_Id;

	public Integer getTonns_Id() {
		return Tonns_Id;
	}

	public void setTonns_Id(Integer tonns_Id) {
		Tonns_Id = tonns_Id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public Kids getKid_Id() {
		return kid_Id;
	}

	public void setKid_Id(Kids kid_Id) {
		this.kid_Id = kid_Id;
	}
}
