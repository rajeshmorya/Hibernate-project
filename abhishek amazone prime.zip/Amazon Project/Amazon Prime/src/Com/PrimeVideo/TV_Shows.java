package Com.PrimeVideo;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.Table;

@Entity
@Table(name = "TV_Shows")
public class TV_Shows 
{
   @Id
   @Column(name = "Tv_ID")
   private Integer Tv_ID; 
   
   @OneToOne(targetEntity= User_Account.class, cascade = CascadeType.ALL)
   @JoinColumn(name = "user_Id", referencedColumnName = "Login_Id")
   private User_Account user_Id;

public Integer getTv_ID() {
	return Tv_ID;
}

public void setTv_ID(Integer tv_ID) {
	Tv_ID = tv_ID;
}

public User_Account getUser_Id() {
	return user_Id;
}

public void setUser_Id(User_Account user_Id) {
	this.user_Id = user_Id;
}
}
