package Com.PrimeVideo;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.Table;

@Entity
@Table(name = "Prime")
public class Prime 
{  
   @Id
   @Column(name = "Prime_Id")
   private Integer Prime_Id;
   
   @Column(name  = "Prime_Plan")
   private String Prime_Plan;
   
   @OneToOne(targetEntity = Your_Account.class,cascade =CascadeType.ALL)
   @JoinColumn(name = "Account_Id", referencedColumnName=  "Your_AccountId")
   private Your_Account Account_Id;

public Integer getPrime_Id() {
	return Prime_Id;
}

public void setPrime_Id(Integer prime_Id) {
	Prime_Id = prime_Id;
}

public String getPrime_Plan() {
	return Prime_Plan;
}

public void setPrime_Plan(String prime_Plan) {
	Prime_Plan = prime_Plan;
}

public Your_Account getAccount_Id() {
	return Account_Id;
}

public void setAccount_Id(Your_Account account_Id) {
	Account_Id = account_Id;
}
   
   
}
