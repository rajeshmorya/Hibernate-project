package Com.PrimeVideo;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

@Entity
@Table(name = "Recommanded_shows")
public class Recommanded_shows
{
  @Id
  @Column(name = "shows_Id")
  private Integer shows_Id;
  
  @Column(name = "show_Name")
  private String show_Name;
  
  
  @ManyToOne(targetEntity = TV_Shows.class, cascade = CascadeType.ALL)
  @JoinColumn(name = "Tv_Id", referencedColumnName = "Tv_ID")
  private TV_Shows Tv_Id;


public Integer getShows_Id() {
	return shows_Id;
}


public void setShows_Id(Integer shows_Id) {
	this.shows_Id = shows_Id;
}


public String getShow_Name() {
	return show_Name;
}


public void setShow_Name(String show_Name) {
	this.show_Name = show_Name;
}


public TV_Shows getTv_Id() {
	return Tv_Id;
}


public void setTv_Id(TV_Shows tv_Id) {
	Tv_Id = tv_Id;
}
}
