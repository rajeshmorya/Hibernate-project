package Com.PrimeVideo;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

@Entity
@Table(name = "Website_Language")
public class Website_Languages 
{ 
  @Id
  @Column(name = "WebsiteId")
  private Integer WebsiteId;
  
  @Column(name = "Language_name")
  private String Language_name;
  
  @ManyToOne(targetEntity = Language.class, cascade = CascadeType.ALL)
  @JoinColumn(name = "lang_id", referencedColumnName = "Language_Code")
  private Language Lang_Id;

public Integer getWebsiteId() {
	return WebsiteId;
}

public void setWebsiteId(Integer websiteId) {
	WebsiteId = websiteId;
}

public String getLanguage_name() {
	return Language_name;
}

public void setLanguage_name(String language_name) {
	Language_name = language_name;
}

public Language getLang_Id() {
	return Lang_Id;
}

public void setLang_Id(Language lang_Id) {
	Lang_Id = lang_Id;
}
}
 
