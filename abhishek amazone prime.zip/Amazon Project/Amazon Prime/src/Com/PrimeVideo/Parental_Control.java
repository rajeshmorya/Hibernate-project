package Com.PrimeVideo;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.Table;

@Entity
@Table(name = "Parental_Control")
public class Parental_Control 
{  
   @Id
   @Column(name = "Parental_Id")
   private Integer Parental_Id;
   
   @OneToOne(targetEntity = Acccount_Settting.class, cascade = CascadeType.ALL)
   @JoinColumn(name = "AccountId", referencedColumnName = "AccountSetting_Id")
   private Acccount_Settting Account_Id;

public Integer getParental_Id() {
	return Parental_Id;
}

public void setParental_Id(Integer parental_Id) {
	Parental_Id = parental_Id;
}

public Acccount_Settting getAccount_Id() {
	return Account_Id;
}

public void setAccount_Id(Acccount_Settting account_Id) {
	Account_Id = account_Id;
}
}
