package Com.PrimeVideo;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.Table;

@Entity
@Table(name = "Auto_Play")
public class Auto_Play 
{  
   @Id
   @Column(name =  "Play_Id")
   private Integer Play_Id;
   
   @Column(name = "Set_Mode")
   private String Set_Mode;
   
   @OneToOne(targetEntity = Playback.class, cascade = CascadeType.ALL)
   @JoinColumn(name = "Playback_Id", referencedColumnName = "Playback_id")
   private Playback Playback_Id;

public Integer getPlay_Id() {
	return Play_Id;
}

public void setPlay_Id(Integer play_Id) {
	Play_Id = play_Id;
}

public String getSet_Mode() {
	return Set_Mode;
}

public void setSet_Mode(String set_Mode) {
	Set_Mode = set_Mode;
}

public Playback getPlayback_Id() {
	return Playback_Id;
}

public void setPlayback_Id(Playback playback_Id) {
	Playback_Id = playback_Id;
}
}
