package Com.PrimeVideo;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import javax.persistence.Id;

@Entity
@Table(name = "Hollywood_Movies")
public class Hollywood_Movies 
{
  @Id  	
  @Column(name = "Movies_Id")	
  private Integer Movies_Id;
  
  @Column(name = "moive_name")
  private String moive_name;
  
  @ManyToOne(targetEntity = Movies.class, cascade = CascadeType.ALL)
  @JoinColumn(name= "Id", referencedColumnName = "Movies_Id")
  private Movies Id;

public Integer getMovies_Id() {
	return Movies_Id;
}

public void setMovies_Id(Integer movies_Id) {
	Movies_Id = movies_Id;
}

public String getMoive_name() {
	return moive_name;
}

public void setMoive_name(String moive_name) {
	this.moive_name = moive_name;
}

public Movies getId() {
	return Id;
}

public void setId(Movies id) {
	Id = id;
}
}
