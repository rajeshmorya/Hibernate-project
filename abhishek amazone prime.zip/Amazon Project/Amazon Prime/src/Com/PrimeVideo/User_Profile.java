package Com.PrimeVideo;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.Table;

@Entity
@Table(name = "User_Profile")
public class User_Profile 
{  
   @Id
   @Column(name ="Profile_Id")
   private Integer Profile_Id;
   
   public Integer getProfile_Id() {
	return Profile_Id;
}

public void setProfile_Id(Integer profile_Id) {
	Profile_Id = profile_Id;
}

public String getProfile_Name() {
	return Profile_Name;
}

public void setProfile_Name(String profile_Name) {
	Profile_Name = profile_Name;
}

public User_Account getAccount() {
	return account;
}

public void setAccount(User_Account account) {
	this.account = account;
}

@Column(name = "Profile_Name")
   private String Profile_Name;
   
   @OneToOne(targetEntity= User_Account.class, cascade=  CascadeType.ALL)
   @JoinColumn(name = "account" , referencedColumnName = "Login_Id")
   private User_Account account;
}
