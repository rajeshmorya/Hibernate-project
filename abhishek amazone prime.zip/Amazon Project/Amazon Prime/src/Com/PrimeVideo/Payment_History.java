package Com.PrimeVideo;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

@Entity
@Table(name = "Payment_History")
public class Payment_History 
{  
	@Id
	@Column(name = "Payment_Id")
   private Integer Payment_Id;
	
	
	@Column(name = "Payment_Mode")
	private String Payment_Mode;
	
	public String getPayment_Mode() {
		return Payment_Mode;
	}

	public void setPayment_Mode(String payment_Mode) {
		Payment_Mode = payment_Mode;
	}

	@ManyToOne(cascade = CascadeType.ALL)
	@JoinColumn(name = "Account_Id", referencedColumnName = "Your_AccountId")
	private Your_Account Account_Id;

	public Integer getPayment_Id() {
		return Payment_Id;
	}

	public void setPayment_Id(Integer payment_Id) {
		Payment_Id = payment_Id;
	}

	public Your_Account getAccount_Id() {
		return Account_Id;
	}

	public void setAccount_Id(Your_Account account_Id) {
		Account_Id = account_Id;
	}
}
