package Com.PrimeVideo;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

@Entity
@Table(name= "Thriller_TV")
public class Thriller_TV 
{
	@Id
	@Column(name = "Thriller_Id")
  private Integer Thriller_Id;
	
	@Column(name=  "shows_name")
	private String shows_name;
	
	@ManyToOne(targetEntity = TV_Shows.class, cascade =CascadeType.ALL)
	@JoinColumn(name = "shows_Id", referencedColumnName = "Tv_ID")
	private TV_Shows shows_Id;

	public Integer getThriller_Id() {
		return Thriller_Id;
	}

	public void setThriller_Id(Integer thriller_Id) {
		Thriller_Id = thriller_Id;
	}

	public String getShows_name() {
		return shows_name;
	}

	public void setShows_name(String shows_name) {
		this.shows_name = shows_name;
	}

	public TV_Shows getShows_Id() {
		return shows_Id;
	}

	public void setShows_Id(TV_Shows shows_Id) {
		this.shows_Id = shows_Id;
	}
}
