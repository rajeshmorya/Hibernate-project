package Com.PrimeVideo;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.Table;

@Entity
@Table(name = "Subtitles")
public class Subtitles 
{
  @Id
  @Column(name = "Subtitle_Id")
  private Integer Subtitles_Id;
  
  @OneToOne(targetEntity = Acccount_Settting.class, cascade = CascadeType.ALL)
  @JoinColumn(name = "account_Id", referencedColumnName = "AccountSetting_Id")
  private Acccount_Settting account_Id;

public Integer getSubtitles_Id() {
	return Subtitles_Id;
}

public void setSubtitles_Id(Integer subtitles_Id) {
	Subtitles_Id = subtitles_Id;
}

public Acccount_Settting getAccount_Id() {
	return account_Id;
}

public void setAccount_Id(Acccount_Settting account_Id) {
	this.account_Id = account_Id;
}
}
