package Com.PrimeVideo;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

@Entity
@Table(name = "Your_Prests")
public class Your_Presets 
{ 
   @Id
   @Column(name = "Your_PresetId")
   private Integer Your_PresetId;
   
   
   @Column(name = "Preset_name")
   private String Preset_name;
   
   public Integer getYour_PresetId() {
	return Your_PresetId;
}

public void setYour_PresetId(Integer your_PresetId) {
	Your_PresetId = your_PresetId;
}

public String getPreset_name() {
	return Preset_name;
}

public void setPreset_name(String preset_name) {
	Preset_name = preset_name;
}

public Subtitles getSub_Id() {
	return sub_Id;
}

public void setSub_Id(Subtitles sub_Id) {
	this.sub_Id = sub_Id;
}

@ManyToOne(targetEntity = Subtitles.class, cascade =CascadeType.ALL)
   @JoinColumn(name = "sub_Id", referencedColumnName ="Subtitle_Id")
   private Subtitles sub_Id;
}
