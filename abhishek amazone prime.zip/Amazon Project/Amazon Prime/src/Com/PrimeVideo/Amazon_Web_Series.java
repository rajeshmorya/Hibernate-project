package Com.PrimeVideo;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

@Entity
@Table(name = "Amazon_Web_Series" )
public class Amazon_Web_Series 
{ 
  @Id
  @Column(name = "AmazonId")
  private Integer AmazonId;	
  
  @Column(name = "Series_name")
  private String Series_Name;
  
  @ManyToOne(targetEntity = Home.class, cascade = CascadeType.ALL)
  @JoinColumn(name = "Home_Id", referencedColumnName = "Home_Id")
  private Home Home_Id;

public Integer getAmazonId() {
	return AmazonId;
}

public void setAmazonId(Integer amazonId) {
	AmazonId = amazonId;
}

public String getSeries_Name() {
	return Series_Name;
}

public void setSeries_Name(String series_Name) {
	Series_Name = series_Name;
}

public Home getHome_Id() {
	return Home_Id;
}

public void setHome_Id(Home home_Id) {
	Home_Id = home_Id;
}

}
