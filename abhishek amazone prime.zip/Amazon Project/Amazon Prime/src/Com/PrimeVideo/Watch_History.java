package Com.PrimeVideo;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.OneToOne;
import javax.persistence.Table;

@Entity
@Table(name = "Watch_History")
public class Watch_History
{
	@Id
	@Column(name = "History_Id")
   private Integer History_ID;
	
	public Integer getHistory_ID() {
		return History_ID;
	}

	public void setHistory_ID(Integer history_ID) {
		History_ID = history_ID;
	}

	public Acccount_Settting getAccount_Id() {
		return account_Id;
	}

	public void setAccount_Id(Acccount_Settting account_Id) {
		this.account_Id = account_Id;
	}

	@OneToOne(targetEntity = Acccount_Settting.class, cascade= CascadeType.ALL)
	private Acccount_Settting account_Id;
   
   
}
