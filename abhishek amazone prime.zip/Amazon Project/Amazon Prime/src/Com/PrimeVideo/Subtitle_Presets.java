package Com.PrimeVideo;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.Table;

@Entity
@Table(name = "Subtitle_Preset")
public class Subtitle_Presets 
{  
  @Id
  @Column(name = "Preset_Id")
   private Integer Presets_Id;
  
  @OneToOne(targetEntity = Subtitles.class, cascade = CascadeType.ALL)
  @JoinColumn(name = "subtitle_id", referencedColumnName = "Subtitle_Id")
  private Subtitles subtilte_Id;

public Integer getPresets_Id() {
	return Presets_Id;
}

public void setPresets_Id(Integer presets_Id) {
	Presets_Id = presets_Id;
}

public Subtitles getSubtilte_Id() {
	return subtilte_Id;
}

public void setSubtilte_Id(Subtitles subtilte_Id) {
	this.subtilte_Id = subtilte_Id;
}
}
