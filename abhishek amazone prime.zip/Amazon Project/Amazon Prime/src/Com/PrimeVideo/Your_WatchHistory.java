package Com.PrimeVideo;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.Table;

@Entity
@Table(name = "Your_WatchHistory")
public class Your_WatchHistory 
{
  @Id
  @Column(name = "Your_HistoryId")
  private Integer Your_HistoryId;
  
  @OneToOne(targetEntity = Watch_History.class, cascade = CascadeType.ALL)
  @JoinColumn(name = "watch_HistoryId", referencedColumnName ="History_Id")
  private Watch_History watch_HistoryId;

public Integer getYour_HistoryId() {
	return Your_HistoryId;
}

public void setYour_HistoryId(Integer your_HistoryId) {
	Your_HistoryId = your_HistoryId;
}

public Watch_History getWatch_HistoryId() {
	return watch_HistoryId;
}

public void setWatch_HistoryId(Watch_History watch_HistoryId) {
	this.watch_HistoryId = watch_HistoryId;
}
}
