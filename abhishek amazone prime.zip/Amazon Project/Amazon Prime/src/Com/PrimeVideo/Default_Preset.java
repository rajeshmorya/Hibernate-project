package Com.PrimeVideo;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.Table;

@Entity
@Table(name = "Default_Preset")
public class Default_Preset 
{   @Id
	@Column(name = "Default_id")
    private Integer Default_Id;
	
	@OneToOne(targetEntity = Subtitles.class, cascade = CascadeType.ALL)
	@JoinColumn(name = "sub_Id", referencedColumnName = "Subtitle_Id")
	private Subtitles sub_Id;

	public Integer getDefault_Id() {
		return Default_Id;
	}

	public void setDefault_Id(Integer default_Id) {
		Default_Id = default_Id;
	}

	public Subtitles getSub_Id() {
		return sub_Id;
	}

	public void setSub_Id(Subtitles sub_Id) {
		this.sub_Id = sub_Id;
	}
}
