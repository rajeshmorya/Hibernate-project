package Com.PrimeVideo;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "User")
public class User
{
 @Id
 @Column(name = "Mobile_No")
 private Integer  Mobile_No;
 
 @Column(name = "User_Name")
 private String User_Name;
 


public Integer getMobile_No() {
	return Mobile_No;
}

public void setMobile_No(Integer mobile_No) {
	Mobile_No = mobile_No;
}

public String getUser_Name() {
	return User_Name;
}

public void setUser_Name(String user_Name) {
	User_Name = user_Name;
}
   	
}