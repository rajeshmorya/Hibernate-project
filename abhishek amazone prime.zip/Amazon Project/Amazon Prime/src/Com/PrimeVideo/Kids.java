package Com.PrimeVideo;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.Table;

@Entity
@Table(name = "Kids")
public class Kids
{
	@Id
	@Column(name = "Kids_Id" )
	private Integer Kids_Id;
   
	@OneToOne(targetEntity = User_Account.class, cascade = CascadeType.ALL)
	@JoinColumn(name = "user_Id", referencedColumnName = "Login_Id")
	private User_Account user_Id;

	public Integer getKids_Id() {
		return Kids_Id;
	}

	public void setKids_Id(Integer kids_Id) {
		Kids_Id = kids_Id;
	}

	public User_Account getUser_Id() {
		return user_Id;
	}

	public void setUser_Id(User_Account user_Id) {
		this.user_Id = user_Id;
	}
	

}
