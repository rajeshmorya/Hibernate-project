package Com.PrimeVideo;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

@Entity
@Table(name = "Register_Another_Device")
public class Register_Another_Device 
{
   @Id
   @Column(name = "Another_DeviceId")
   private Integer Another_DeviceId;
   
   @ManyToOne(targetEntity = Your_Devices.class, cascade = CascadeType.ALL)
   @JoinColumn(name = "Device_Id", referencedColumnName = "Device_Id")
   private Your_Devices Device_Id;

public Integer getAnother_DeviceId() {
	return Another_DeviceId;
}

public void setAnother_DeviceId(Integer another_DeviceId) {
	Another_DeviceId = another_DeviceId;
}

public Your_Devices getDevice_Id() {
	return Device_Id;
}

public void setDevice_Id(Your_Devices device_Id) {
	Device_Id = device_Id;
}
}
