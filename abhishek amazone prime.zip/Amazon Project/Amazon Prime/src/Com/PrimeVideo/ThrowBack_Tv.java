package Com.PrimeVideo;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

@Entity
@Table(name = "ThrowBack_Tv")
public class ThrowBack_Tv 
{
	@Id
	@Column(name = "Tv_Id")
  private Integer Tv_Id;
	
	public Integer getTv_Id() {
		return Tv_Id;
	}

	public void setTv_Id(Integer tv_Id) {
		Tv_Id = tv_Id;
	}

	public String getShows_name() {
		return shows_name;
	}

	public void setShows_name(String shows_name) {
		this.shows_name = shows_name;
	}

	public TV_Shows getTV_Id() {
		return TV_Id;
	}

	public void setTV_Id(TV_Shows tV_Id) {
		TV_Id = tV_Id;
	}

	@Column(name ="shows_name")
	private String shows_name;
	
	@ManyToOne(targetEntity = TV_Shows.class, cascade = CascadeType.ALL)
	@JoinColumn(name = "Tv_Ids", referencedColumnName = "Tv_ID")
	
	private TV_Shows TV_Id;
}
