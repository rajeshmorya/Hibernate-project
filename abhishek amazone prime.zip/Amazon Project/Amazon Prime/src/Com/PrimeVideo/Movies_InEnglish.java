package Com.PrimeVideo;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

@Entity
@Table(name = "Movies_InEnglish" )
public class Movies_InEnglish 
{   
	@Id
	@Column(name = "Movies_Id")
    private Integer Movies_Id;
	
	@Column(name = "Movies_name")
	private String Movies_name;
	
	@ManyToOne(targetEntity = Home.class, cascade = CascadeType.ALL)
	@JoinColumn(name = "Home_Id", referencedColumnName = "Home_Id")
	private Home Home_Id;

	public Integer getMovies_Id() {
		return Movies_Id;
	}

	public void setMovies_Id(Integer movies_Id) {
		Movies_Id = movies_Id;
	}

	public String getMovies_name() {
		return Movies_name;
	}

	public void setMovies_name(String movies_name) {
		Movies_name = movies_name;
	}

	public Home getHome_Id() {
		return Home_Id;
	}

	public void setHome_Id(Home home_Id) {
		Home_Id = home_Id;
	}
}
