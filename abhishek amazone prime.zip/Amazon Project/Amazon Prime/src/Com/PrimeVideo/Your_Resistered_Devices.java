package Com.PrimeVideo;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

@Entity
@Table(name = "Your_Registerd_Devices")
public class Your_Resistered_Devices 
{
  @Id
  @Column(name = "Device_Id")
  private Integer Device_Id;
  
  @Column(name = "Device_Name")
  private String Device_Name;
  
  @ManyToOne(targetEntity = Your_Devices.class, cascade =CascadeType.ALL)
  @JoinColumn(name = "Your_Id", referencedColumnName = "Device_Id")
  private Your_Devices Your_Id;

public Integer getDevice_Id() {
	return Device_Id;
}

public void setDevice_Id(Integer device_Id) {
	Device_Id = device_Id;
}

public String getDevice_Name() {
	return Device_Name;
}

public void setDevice_Name(String device_Name) {
	Device_Name = device_Name;
}

public Your_Devices getYour_Id() {
	return Your_Id;
}

public void setYour_Id(Your_Devices your_Id) {
	Your_Id = your_Id;
}
}
