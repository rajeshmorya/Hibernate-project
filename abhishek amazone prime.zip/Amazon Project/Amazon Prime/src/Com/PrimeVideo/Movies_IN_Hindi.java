package Com.PrimeVideo;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

@Entity
@Table(name = "Movies_IN_Hindi")
public class Movies_IN_Hindi 
{
  @Id
  @Column(name = "Hindi_Id")
  private Integer Hindi_Id;
  
  @Column
  private String Moive_name;
  
  public String getMoive_name() {
	return Moive_name;
}

public void setMoive_name(String moive_name) {
	Moive_name = moive_name;
}

@ManyToOne(targetEntity = Home.class, cascade = CascadeType.ALL)
  @JoinColumn(name ="Home_Id",referencedColumnName = "Home_Id" )
  private Home Home_Id;

public Integer getHindi_Id() {
	return Hindi_Id;
}

public void setHindi_Id(Integer hindi_Id) {
	Hindi_Id = hindi_Id;
}

public Home getHome_Id() {
	return Home_Id;
}

public void setHome_Id(Home home_Id) {
	Home_Id = home_Id;
}
}
