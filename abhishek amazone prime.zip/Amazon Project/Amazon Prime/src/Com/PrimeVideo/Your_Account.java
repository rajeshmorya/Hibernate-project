package Com.PrimeVideo;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.Table;

@Entity
@Table(name = "Your_Account")
public class Your_Account 
{ 
  @Id
  @Column(name = "Your_AccountId")
   private Integer Your_AccountId;
  
   @OneToOne(targetEntity = Acccount_Settting.class, cascade = CascadeType.ALL)
   @JoinColumn(name = "Acc_Id", referencedColumnName = "AccountSetting_Id")
   private Acccount_Settting  Acc_Id;

public Integer getYour_AccountId() {
	return Your_AccountId;
}

public void setYour_AccountId(Integer your_AccountId) {
	Your_AccountId = your_AccountId;
}

public Acccount_Settting getAcc_Id() {
	return Acc_Id;
}

public void setAcc_Id(Acccount_Settting acc_Id) {
	Acc_Id = acc_Id;
}
}
