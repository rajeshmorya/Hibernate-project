package Com.PrimeVideo;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

@Entity
@Table(name = "Bollywood_Movies")
public class Bollywood_Movies 
{
	@Id
	@Column(name  = "Bollywood_Id" )
    private Integer Bollywood_Id;
	
	@Column(name = "MovieName")
	private String MovieName;
	
	
	@ManyToOne(targetEntity = Movies.class, cascade = CascadeType.ALL)
	@JoinColumn(name = "Movies_Id", referencedColumnName = "Movies_Id")
	private Movies Movies_Id;


	public Integer getBollywood_Id() {
		return Bollywood_Id;
	}


	public void setBollywood_Id(Integer bollywood_Id) {
		Bollywood_Id = bollywood_Id;
	}


	public String getMovieName() {
		return MovieName;
	}


	public void setMovieName(String movieName) {
		MovieName = movieName;
	}


	public Movies getMovies_Id() {
		return Movies_Id;
	}


	public void setMovies_Id(Movies movies_Id) {
		Movies_Id = movies_Id;
	}
}
