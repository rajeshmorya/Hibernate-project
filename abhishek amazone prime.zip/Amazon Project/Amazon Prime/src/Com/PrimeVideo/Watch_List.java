package Com.PrimeVideo;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.Table;

@Entity
@Table(name = "Watch_List")
public class Watch_List 
{ 
  @Id
  @Column(name = "List_Id")
  private Integer List_Id;
  
  @Column(name = "List_Name")
  private String List_Name;
  
  @OneToOne(targetEntity =  User_Profile.class, cascade = CascadeType.ALL)
  @JoinColumn(name = "Profile_Id",referencedColumnName = "Profile_Id")
  private  User_Profile Profile_Id;

public Integer getList_Id() {
	return List_Id;
}

public void setList_Id(Integer list_Id) {
	List_Id = list_Id;
}

public String getList_Name() {
	return List_Name;
}

public void setList_Name(String list_Name) {
	List_Name = list_Name;
}

public User_Profile getProfile_Id() {
	return Profile_Id;
}

public void setProfile_Id(User_Profile profile_Id) {
	Profile_Id = profile_Id;
}
  
}
