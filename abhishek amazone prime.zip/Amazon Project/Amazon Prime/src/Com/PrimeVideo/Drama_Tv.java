package Com.PrimeVideo;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

@Entity
@Table(name = "Drama_Tv")
public class Drama_Tv
{
	@Id
	@Column(name = "Drama_Id")
  private Integer Drama_Id;
	
	@Column(name = "show_name")
	private String show_name;
	
	@ManyToOne(targetEntity = TV_Shows.class, cascade = CascadeType.ALL)
	@JoinColumn(name = "Tv_Id", referencedColumnName = "Tv_ID")
	private TV_Shows Tv_Id;

	public Integer getDrama_Id() {
		return Drama_Id;
	}

	public void setDrama_Id(Integer drama_Id) {
		Drama_Id = drama_Id;
	}

	public String getShow_name() {
		return show_name;
	}

	public void setShow_name(String show_name) {
		this.show_name = show_name;
	}

	public TV_Shows getTv_Id() {
		return Tv_Id;
	}

	public void setTv_Id(TV_Shows tv_Id) {
		Tv_Id = tv_Id;
	}
}
