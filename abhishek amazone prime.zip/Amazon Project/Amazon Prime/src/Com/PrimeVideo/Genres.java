package Com.PrimeVideo;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToOne;
import javax.persistence.Table;

@Entity
@Table(name = "Genres")
public class Genres 
{
	@Id
	@Column(name = "Genres_id")
  private Integer Genres_id;
	
	@Column(name = "Genre_Type")
	private String Genre_Type;
	
	public Integer getGenres_id() {
		return Genres_id;
	}

	public void setGenres_id(Integer genres_id) {
		Genres_id = genres_id;
	}

	public String getGenre_Type() {
		return Genre_Type;
	}

	public void setGenre_Type(String genre_Type) {
		Genre_Type = genre_Type;
	}

	public Home getHome_id() {
		return Home_id;
	}

	public void setHome_id(Home home_id) {
		Home_id = home_id;
	}

	@ManyToOne(targetEntity = Home.class, cascade = CascadeType.ALL)
	@JoinColumn(name = "Home_id")
	private Home Home_id;
}
