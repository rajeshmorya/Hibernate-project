package Com.PrimeVideo;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.Table;

@Entity
@Table(name = "Language")
public class Language 
{
  @Id
  @Column(name = "Language_Code")
  private Integer Language_Code;
  
  @OneToOne(targetEntity = Acccount_Settting.class, cascade = CascadeType.ALL )
  @JoinColumn(name =  "account_Id", referencedColumnName = "AccountSetting_Id")
  private Acccount_Settting account_Id;

public Integer getLanguage_Code() {
	return Language_Code;
}

public void setLanguage_Code(Integer language_Code) {
	Language_Code = language_Code;
}

public Acccount_Settting getAccount_Id() {
	return account_Id;
}

public void setAccount_Id(Acccount_Settting account_Id) {
	this.account_Id = account_Id;
}
}
