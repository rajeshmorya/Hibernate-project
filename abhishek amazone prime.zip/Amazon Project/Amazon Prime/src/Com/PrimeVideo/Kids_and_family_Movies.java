package Com.PrimeVideo;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

@Entity
@Table(name ="Kids_and_family_Movies")
public class Kids_and_family_Movies 
{
	@Id
	@Column(name = "familyMovies_Id")
   private Integer familyMovies_Id;
	
	@Column(name = "Moive_Name")
	private String Moive_Name;
	
	@ManyToOne(targetEntity = Kids.class, cascade =CascadeType.ALL)
	@JoinColumn(name  = "kid_id", referencedColumnName = "Kids_Id" )		
	private Kids kid_id;

	public Integer getFamilyMovies_Id() {
		return familyMovies_Id;
	}

	public void setFamilyMovies_Id(Integer familyMovies_Id) {
		this.familyMovies_Id = familyMovies_Id;
	}

	public String getMoive_Name() {
		return Moive_Name;
	}

	public void setMoive_Name(String moive_Name) {
		Moive_Name = moive_Name;
	}

	public Kids getKid_id() {
		return kid_id;
	}

	public void setKid_id(Kids kid_id) {
		this.kid_id = kid_id;
	}
}
