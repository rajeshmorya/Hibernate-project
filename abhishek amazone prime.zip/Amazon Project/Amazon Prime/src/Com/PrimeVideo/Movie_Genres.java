package Com.PrimeVideo;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.ManyToOne;
import javax.persistence.OneToOne;
import javax.persistence.Table;

@Entity
@Table(name = "Movie_Genres")
public class Movie_Genres 
{
  @Id
  @Column(name = "Movie_GenresId")
  
  private Integer Movie_GenresId;
  
  public Integer getMovie_GenresId() {
	return Movie_GenresId;
}

public void setMovie_GenresId(Integer movie_GenresId) {
	Movie_GenresId = movie_GenresId;
}

public String getGenre_Type() {
	return Genre_Type;
}

public void setGenre_Type(String genre_Type) {
	Genre_Type = genre_Type;
}

public Movies getMoive_Id() {
	return moive_Id;
}

public void setMoive_Id(Movies moive_Id) {
	this.moive_Id = moive_Id;
}

@Column(name = "Genre_Type")
  private String Genre_Type;
  
  @ManyToOne(targetEntity= Movies.class, cascade = CascadeType.ALL)
  private Movies moive_Id;
}
