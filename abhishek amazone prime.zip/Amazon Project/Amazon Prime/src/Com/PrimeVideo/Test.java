package Com.PrimeVideo;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.AnnotationConfiguration;

public class Test extends LogicFile {

	public static void main(String[] args) {

		/* Method for OTO User & User_Account Create Operation */

		// LogicFile f = new LogicFile();

		// f.User_UserAccount();

		/* Method for OTO User_Account and User_Profile Operation */

		// LogicFile f1 = new LogicFile();

		// f1.UserAccount_UsrProfile();

		/* Method for OTO User_Profile and Watch_list Operation */

		// LogicFile f2 = new LogicFile();

		// f2.UsrProfile_WathList();

		/* Method for OTO User_Profile and AccountSetting Operation */

		// LogicFile f3 = new LogicFile();

		// f3.UsrProfile_AccountSetting();

		/* Method for OTO User_Profile and WatchAnywhere Operation */

		// LogicFile f4 = new LogicFile();

		// f4.UsrProfile_WatchAnywhere();

		/* Method for OTO User_Profile and HelpMenu Operation */

		// LogicFile f5 = new LogicFile();

		// f5.UsrProfile_HelpMenu();

		/* Method for OTO AccountSetting and YourAccount Operation */

		// LogicFile f6 = new LogicFile();

		// f6.AccountSetting_YourAccount();

		/* Method for OTO YourAccount and Your_Details Operation */

		// LogicFile f7 = new LogicFile();

		// f7.YourAccount_YourDetails();

		/* Method for OTO YourAccount and Prime */

		// LogicFile f8 = new LogicFile();

		// f8.YourAccount_Prime();

		/* Method for MTO YourAccount and Payment History */

		// LogicFile f9 = new LogicFile();

		// f9.YourAccount_PaymentHistory();

		/* Method for OTO AccountSetting and Playback */

		// LogicFile f10 = new LogicFile();

		// f10.AccountSetting_Palyback();

		/* Method for OTO Playback and Autoplay */

		// LogicFile f11 = new LogicFile();

		// f11.Palyback_Autoplay();

		/* Method for OTO AccountSetting and Parental_Control */

		// LogicFile f12 = new LogicFile();

		// f12.AccountSetting_ParentalControl();

		/* Method for OTO Parental_Control and Video_Pin */

		// LogicFile f13 = new LogicFile();

		// f13.ParentalControl_Prime_VideoPin();

		/* Method for OTO Parental_Control and Video_Pin */

		// LogicFile f14 = new LogicFile();

		// f14.ParentalControl_Restriction();

		/* Method for OTO AccountSetting and Subtitles */

		// LogicFile f15 = new LogicFile();

		// f15.AccountSetting_Subtitles();

		/* Method for OTO Subtitles and Presets */

		// LogicFile f16 = new LogicFile();

		// f16.Subtitle_SubtiltePresets();

		/* Method for OTO Subtitles and Presets */

		// LogicFile f17 = new LogicFile();

		// f17.Subtilte_DefaultPreset();

		/* Method for OTO Subtitles and Your_Preset */

		// LogicFile f18 = new LogicFile();

		// f18.Subtilte_YourPreset();

		/* Method for OTO Subtitles and Your_Preset */

		// LogicFile f19 = new LogicFile();

		// f19.AccountSetting_YourDevice();

		/* Method for OTO Your_Device and Registerd_Device */

		// LogicFile f20 = new LogicFile();

		// f20.YourDevice_RegisterDevice();

		/* Method for MTO Your_Device and Your_RegisteredDevice */

		// LogicFile f21 = new LogicFile();

		// f21.YourDevice_YourDevices();

		/* Method for OTO AccountSetting and Languages */

		// LogicFile f22 = new LogicFile();

		// f22.AccountSetting_Languages();

		/* Method for MTO Languages and Website Languages */

		// LogicFile f23 = new LogicFile();

		// f23.Languages_WebsiteLanguages();

		/* Method for OTO AccountSetting and Watch History */

		// LogicFile f24 = new LogicFile();

		// f24.AccountSetting_WatchHistory();

		/* Method for OTO Watch History and Your_History */

		// LogicFile f25 = new LogicFile();

		// f25.WatchHistory_YourHistory();

		/* Method for OTO UserAccount and Home */

		// LogicFile f26 = new LogicFile();

		// f26.UserAccount_Home();

		/* Method for OTO UserAccount and TVShows */

		// LogicFile f27 = new LogicFile();

		// f27.UserAccount_TvShows();

		/* Method for OTO UserAccount and Movies */

		// LogicFile f28 = new LogicFile();

		// f28.UserAccount_Movies();

		/* Method for OTO UserAccount and Kids */

		// LogicFile f29 = new LogicFile();

		// f29.UserAccount_Kids();

		/* Method for MTO Home and HindiMovies */

		// LogicFile f30 = new LogicFile();

		// f30.Home_HindiMovies();

		/* Method for OTO Home a nd WebSeries */

		// LogicFile f31 = new LogicFile();

		// f31.Home_AmazonWebSeries();

		/* Method for MTO Home a MoiesInEnglish */

		// LogicFile f32 = new LogicFile();

		// f32.Home_MoviesinEnglish();
		/* Method for MTO Home a Genres */

		// LogicFile f33 = new LogicFile();

		// f33.Home_Genres();

		/* Method for MTO TVShows and Recommanded */

		// LogicFile f34 = new LogicFile();

		// f34.TVshow_Recommanded();

		/* Method for MTO TVShows and Throwback */

		// LogicFile f35 = new LogicFile();

		// f35.TVshow_Throwback();

		/* Method for MTO TVShows and Thriller */

		// LogicFile f36 = new LogicFile();

		// f36.TVshow_Thriller();
		/* Method for MTO TVShows and DramaTv */

		// LogicFile f37 = new LogicFile();

		// f37.TVshow_DramaTv()

		/* Method for MTO TVShows and DramaTv */

		// LogicFile f38 = new LogicFile();

		// f38.Movies_Hollywood();

		/* Method for MTO Movies and MovisLanguage */

		// LogicFile f39 = new LogicFile();

		// f39.Movies_Language();

		/* Method for MTO Movies and Bollywood_Moive */

		// LogicFile f40 = new LogicFile();

		// f40.Movies_Bollywood();

		/* Method for MTO Movies and Genres */

		// LogicFile f41 = new LogicFile();

		// f41.Movies_Genres();

		/* Method for MTO kids and family */

		// LogicFile f42 = new LogicFile();

		// f42.Kids_familyMovies();

		/* Method for MTO Kids and fantasy */

		// LogicFile f43 = new LogicFile();

		// f43.Kids_Fantasy();

		/* Method for MTO Kids and IndianToons */

		LogicFile f44 = new LogicFile();

		f44.Kids_IndianToons();

	}

}
