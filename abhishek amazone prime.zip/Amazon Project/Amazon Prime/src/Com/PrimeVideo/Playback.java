package Com.PrimeVideo;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.Table;

@Entity 
@Table(name = "Playback")
public class Playback
{
   @Id
   @Column(name = "Playback_id")
   private Integer Playback_Id;
   
   @OneToOne(targetEntity = Acccount_Settting.class, cascade = CascadeType.ALL)
   @JoinColumn(name = "Account_Id", referencedColumnName = "AccountSetting_Id")
   private Acccount_Settting Account_Id;

public Integer getPlayback_Id() {
	return Playback_Id;
}

public void setPlayback_Id(Integer playback_Id) {
	Playback_Id = playback_Id;
}

public Acccount_Settting getAccount_Id() {
	return Account_Id;
}

public void setAccount_Id(Acccount_Settting account_Id) {
	Account_Id = account_Id;
}
	
}
