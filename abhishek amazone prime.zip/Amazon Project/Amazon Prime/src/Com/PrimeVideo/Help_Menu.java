package Com.PrimeVideo;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.Table;

@Entity
@Table(name = "Help_Menu")
public class Help_Menu 
{   @Id
	@Column(name = "Help_Id")
    private Integer Help_Id;
    
    @OneToOne(targetEntity = User_Profile.class, cascade = CascadeType.ALL)
    @JoinColumn(name = "Profile_Id", referencedColumnName = "Profile_Id")
    private User_Profile Profil_Id;

	public Integer getHelp_Id() {
		return Help_Id;
	}

	public void setHelp_Id(Integer help_Id) {
		Help_Id = help_Id;
	}

	public User_Profile getProfil_Id() {
		return Profil_Id;
	}

	public void setProfil_Id(User_Profile profil_Id) {
		Profil_Id = profil_Id;
	}
}
