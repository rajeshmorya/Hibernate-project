package Com.PrimeVideo;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.Table;

@Entity
@Table(name = "Movies_ByLanguage")
public class Movies_ByLanguage 
{
  @Id
  @Column(name = "Movies_Id")
  private Integer Movies_Id;
  
  @Column(name = "Language_name")
  private String Language_name;
  
  @OneToOne(targetEntity = Movies.class, cascade =CascadeType.ALL)
  @JoinColumn(name = "movie_Id", referencedColumnName = "Movies_Id")
  private Movies movie_Id;

public Integer getMovies_Id() {
	return Movies_Id;
}

public void setMovies_Id(Integer movies_Id) {
	Movies_Id = movies_Id;
}

public String getLanguage_name() {
	return Language_name;
}

public void setLanguage_name(String language_name) {
	Language_name = language_name;
}

public Movies getMovie_Id() {
	return movie_Id;
}

public void setMovie_Id(Movies movie_Id) {
	this.movie_Id = movie_Id;
}
}
