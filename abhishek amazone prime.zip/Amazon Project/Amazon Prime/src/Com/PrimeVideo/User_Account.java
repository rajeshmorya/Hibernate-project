package Com.PrimeVideo;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.Table;

@Entity
@Table(name = "User_Account")
public class User_Account
{  
   @Id
   @Column(name = "Login_Id")
   private Integer Login_Id;
   
   @Column(name = "Login_Password")
   private String Login_Password;
   
   @OneToOne(targetEntity = User.class,cascade = CascadeType.ALL)
   @JoinColumn(name = "User_Id", referencedColumnName = "Mobile_No")
   private User User_Id;

public Integer getLogin_Id() {
	return Login_Id;
}

public void setLogin_Id(Integer login_Id) {
	Login_Id = login_Id;
}

public String getLogin_Password() {
	return Login_Password;
}

public void setLogin_Password(String login_Password) {
	Login_Password = login_Password;
}

public User getUser_Id() {
	return User_Id;
}

public void setUser_Id(User user_Id) {
	User_Id = user_Id;
}
}
