package Com.PrimeVideo;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.Table;

@Entity
@Table(name = "Your_Details")
public class Your_Details 
{   @Id
	@Column(name = "Details_Id")
    private Integer Details_Id;
    
    @Column(name = "Email")
    private String Email;
    
    @OneToOne(targetEntity = Your_Account.class, cascade =  CascadeType.ALL)
    @JoinColumn(name = "Account_Id", referencedColumnName = "Your_AccountId")
    private Your_Account Account_Id;

	public Integer getDetails_Id() {
		return Details_Id;
	}

	public void setDetails_Id(Integer details_Id) {
		Details_Id = details_Id;
	}

	public String getEmail() {
		return Email;
	}

	public void setEmail(String email) {
		Email = email;
	}

	public Your_Account getAccount_Id() {
		return Account_Id;
	}

	public void setAccount_Id(Your_Account account_Id) {
		Account_Id = account_Id;
	}
}
