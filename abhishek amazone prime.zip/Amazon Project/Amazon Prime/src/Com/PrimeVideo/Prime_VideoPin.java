package Com.PrimeVideo;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.Table;

@Entity
@Table(name  = "Prime_VideoPin")
public class Prime_VideoPin 
{ 
   @Id
   @Column(name = "Video_Pin")
   private Integer Video_Pin;
   
   @OneToOne(targetEntity = Parental_Control.class, cascade = CascadeType.ALL)
   @JoinColumn(name = "Control_Id", referencedColumnName ="Parental_Id" )
   private Parental_Control Control_Id;

public Integer getVideo_Pin() {
	return Video_Pin;
}

public void setVideo_Pin(Integer video_Pin) {
	Video_Pin = video_Pin;
}

public Parental_Control getControl_Id() {
	return Control_Id;
}

public void setControl_Id(Parental_Control control_Id) {
	Control_Id = control_Id;
}
}
