package Com.PrimeVideo;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.Table;

@Entity
@Table(name = "Account_Setting")
public class Acccount_Settting 

{  
	@Id
	@Column(name = "AccountSetting_Id")
    private Integer Account_SettingId;
	
	@OneToOne(targetEntity = User_Profile.class,cascade = CascadeType.ALL)
	@JoinColumn(name = "Profile_Id", referencedColumnName = "Profile_Id")
	private User_Profile Profile_Id;

	public Integer getAccount_SettingId() {
		return Account_SettingId;
	}

	public void setAccount_SettingId(Integer account_SettingId) {
		Account_SettingId = account_SettingId;
	}

	public User_Profile getProfile_Id() {
		return Profile_Id;
	}

	public void setProfile_Id(User_Profile profile_Id) {
		Profile_Id = profile_Id;
	}
	 
}
