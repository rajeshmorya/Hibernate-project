package Com.PrimeVideo;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.Table;

@Entity
@Table(name = "Home")
public class Home 
{ 
  @Id	
  @Column(name = "Home_Id")
  private Integer Home_Id;
  
  @OneToOne(targetEntity = User_Account.class, cascade = CascadeType.ALL)
  @JoinColumn(name = "User_AccountId", referencedColumnName=  "Login_Id")
  private User_Account User_AccountId;

public Integer getHome_Id() {
	return Home_Id;
}

public void setHome_Id(Integer home_Id) {
	Home_Id = home_Id;
}

public User_Account getUser_AccountId() {
	return User_AccountId;
}

public void setUser_AccountId(User_Account user_AccountId) {
	User_AccountId = user_AccountId;
}
  
}
