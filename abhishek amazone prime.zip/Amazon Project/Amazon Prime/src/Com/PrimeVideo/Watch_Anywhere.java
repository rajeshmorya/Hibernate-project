package Com.PrimeVideo;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Table;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;

@Entity
@Table(name = "Watch_Anywhere")

public class Watch_Anywhere 
{  
   @Id
   @Column(name = "Id")
   private Integer Id; 
   
   @OneToOne(targetEntity = User_Profile.class, cascade  = CascadeType.ALL)
   @JoinColumn(name = "Profile_Id", referencedColumnName = "Profile_Id")
   private User_Profile Profile_Id;

public Integer getId() {
	return Id;
}

public void setId(Integer id) {
	Id = id;
}

public User_Profile getProfile_Id() {
	return Profile_Id;
}

public void setProfile_Id(User_Profile profile_Id) {
	Profile_Id = profile_Id;
}
   
   
}
