package Com.PrimeVideo;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

import org.hibernate.annotations.FilterJoinTable;

@Entity
@Table(name = "Fantasy_Movies")
public class Fantasy_Movies 
{
  @Id
  @Column(name= "Fantasy_Id")
  private Integer Fantasy_Id;
  
  @Column(name = "moive_Name")
  private String moive_Name;
  
  @ManyToOne(targetEntity = Kids.class, cascade = CascadeType.ALL)
  @JoinColumn(name = "Kid_Id", referencedColumnName = "Kids_Id")
  private Kids Kid_Id;

public Integer getFantasy_Id() {
	return Fantasy_Id;
}

public void setFantasy_Id(Integer fantasy_Id) {
	Fantasy_Id = fantasy_Id;
}

public String getMoive_Name() {
	return moive_Name;
}

public void setMoive_Name(String moive_Name) {
	this.moive_Name = moive_Name;
}

public Kids getKid_Id() {
	return Kid_Id;
}

public void setKid_Id(Kids kid_Id) {
	Kid_Id = kid_Id;
}
}
